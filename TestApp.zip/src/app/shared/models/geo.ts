export interface Geo {
    lat: string;
    lng: string;
  }