export const environment = {
  production: false,
  getUsers: 'https://jsonplaceholder.typicode.com/users',
  getPosts: 'https://jsonplaceholder.typicode.com/posts'
};